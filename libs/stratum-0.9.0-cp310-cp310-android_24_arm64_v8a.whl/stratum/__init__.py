# Stratum Runtime Entry Point. Auto-generated. DO NOT EDIT.
# Optional dynamic-mode class loader (see 08_pyi_emit --mode dynamic).
# In a static-mode wheel (the default, unchanged pipeline) stratum/_dynamic.py
# simply doesn't exist in the wheel, ImportError is swallowed, and nothing
# below this block changes behavior at all.
try:
    from . import _dynamic as _stratum_dynamic
    _stratum_dynamic.install()
except ImportError:
    pass

from . import _stratum as _core
from stratum.core.stratum_object import StratumObject
import importlib
import sys


def getActivity():
    """Return the current Android Activity, or None before onCreate."""
    ptr = _core.get_activity_ptr()
    if not ptr:
        return None
    from stratum.android.app.Activity import Activity
    return Activity(_ptr=ptr)


get_activity = getActivity
stratum_get_activity = getActivity


def stratum_cast(obj, target_cls):
    """Safely cast an object or pointer to target_cls with JNI IsInstanceOf verification."""
    if obj is None:
        return None
    return target_cls.from_ptr(obj)


stratum_cast_to = stratum_cast


def setContentView(activity, view) -> None:
    """Mount a View as the Activity's root content view."""
    act_ptr = getattr(activity, "_ptr", activity)
    view_ptr = getattr(view, "_ptr", view)
    _core.set_content_view(act_ptr, view_ptr)


set_content_view = setContentView


def allocate_direct_buffer(capacity: int):
    """Allocate an off-heap direct java.nio.ByteBuffer."""
    ptr = _core.allocate_direct_buffer(capacity)
    if not ptr:
        return None
    from stratum.core.stratum_object import _wrap_instance
    return _wrap_instance(ptr, "java.nio.ByteBuffer")


def surface_to_native_window(surface) -> int:
    """Acquire an ANativeWindow* pointer (as an integer) from an android.view.Surface."""
    s_ptr = getattr(surface, "_ptr", surface)
    return _core.surface_to_native_window(s_ptr)


def release_native_window(win_ptr: int) -> None:
    """Release an ANativeWindow* handle previously acquired."""
    _core.release_native_window(win_ptr)


def to_java(obj):
    """Recursively converts Python data (dict, list, int, float, bool, str, bytes)
    into a real Java object (HashMap, ArrayList, Boxed primitives, byte[]).
    Existing StratumObject instances retain their underlying Java reference."""
    if obj is None:
        return None
    if hasattr(obj, "_ptr"):
        return obj
    ptr = _core.to_java(obj)
    if not ptr:
        return None
    return StratumObject(_ptr=ptr)


def to_py(obj):
    """Recursively converts Java objects (Map, List, Bundle, boxed primitives,
    and arrays) into native Python data (dict, list, int, float, bool, str, bytes).
    Non-data Java objects are wrapped into typed StratumObject instances."""
    if obj is None:
        return None
    # 100% DEFENSIVE GUARD: If the object does not have _ptr, it is ALREADY native
    # Python data (e.g. an int, bool, float, str, list, dict). Never treat a bare
    # Python numeric value as a raw JNI memory address!
    if not hasattr(obj, "_ptr"):
        return obj
    ptr = getattr(obj, "_ptr", None)
    if not isinstance(ptr, int) or ptr == 0:
        return None
    return _core.to_py(ptr)


def register_function(name: str, fn) -> None:
    """Registers a Python function so Java can call it via
    StratumRuntimeLookup.callPython(name, ...). Thin wrapper over the
    existing register_callback -- no new native binding needed."""
    register_callback(f"app#{name}", fn)


def export(fn_or_name):
    """Decorator to expose a Python function to Java.

    Usage:
        @stratum.export
        def calculate_score(points, multiplier):
            return points * multiplier
    """
    if callable(fn_or_name):
        register_function(fn_or_name.__name__, fn_or_name)
        return fn_or_name
    def decorator(fn):
        register_function(fn_or_name, fn)
        return fn
    return decorator


def to_java_array(items, component_type: str):
    """Converts a Python list into a strongly-typed native Java array
    (T[]), for APIs whose signature is erased to Object (e.g.
    Camera2's CaptureRequest.set(Key<T>, T)), and used internally by
    stratum.reflect's call_java()/call_java_method().

    component_type: Java FQN of the element type (required -- guessing
    it from list contents risks a ClassCastException on an empty or
    mixed-type list).
    """
    Class = importlib.import_module("stratum.java.lang.Class").Class
    Array = importlib.import_module("stratum.java.lang.reflect.Array").Array
    loader_ptr = _core.get_app_classloader_ptr()
    if loader_ptr:
        ClassLoader = importlib.import_module("stratum.java.lang.ClassLoader").ClassLoader
        comp_cls = Class.forName(component_type, True, ClassLoader(_ptr=loader_ptr))
    else:
        comp_cls = Class.forName(component_type)
    arr = Array.newInstance(comp_cls, len(items))
    for i, item in enumerate(items):
        Array.set(arr, i, item)
    return arr


def remove_callback(key: str) -> None:
    """Release a stored Python callback (listener/adapter) by its key,
    if you tracked it. Reduces the g_callbacks map growth flagged by the
    logcat warning that fires once it exceeds ~10,000 live entries."""
    _core.remove_callback(key)


def remove_callbacks_by_prefix(prefix: str) -> int:
    """Remove all stored callbacks matching a given prefix."""
    return _core.remove_callbacks_by_prefix(prefix)


def callback_count() -> int:
    """Number of Python callbacks currently retained by the native side."""
    return _core.stratum_callback_count()


def register_callback(key: str, fn) -> None:
    """Bind a Python callable to a native callback key (or 'key#method').
    Used internally by stratum.ui.CustomCanvasView."""
    _core.register_callback(key, fn)


def create_stratum_view(key: str):
    """Construct a native com.stratum.runtime.StratumView bound to `key`.
    Prefer stratum.ui.CustomCanvasView instead of calling this directly."""
    ptr = _core.create_stratum_view(key)
    if not ptr:
        return None
    from stratum.core.stratum_object import _wrap_instance
    return _wrap_instance(ptr, "android.view.View")

_main_handler = None

def run_on_ui_thread(fn, *args, **kwargs) -> None:
    """Posts a callable to Android's Main Looper (UI thread). Required
    before touching any View from a background thread, timer, sensor
    callback, or network response -- Android throws
    CalledFromWrongThreadException otherwise. Lazily imports
    android.os.Handler/Looper, so this costs nothing if never called."""
    global _main_handler
    if _main_handler is None:
        from stratum.android.os.Handler import Handler
        from stratum.android.os.Looper import Looper
        _main_handler = Handler(Looper.getMainLooper())

    def _runner():
        fn(*args, **kwargs)

    _main_handler.post(_runner)


def ui_thread(fn):
    """Decorator: always runs the wrapped function on the Android UI thread."""
    def wrapper(*args, **kwargs):
        run_on_ui_thread(fn, *args, **kwargs)
    return wrapper



def set_log_enabled(enabled: bool) -> None:
    """Toggle runtime logging. Only has any effect if this .so was
    compiled with --log-level 1 or 2 in Stage 07 — level 0 (the default)
    strips all logging code at compile time, so this call is a silent
    no-op on a production build."""
    _core.set_log_enabled(enabled)



def _auto_register_lifecycle() -> None:
    try:
        main = sys.modules.get("main") or importlib.import_module("main")
    except Exception:
        return
    for name in ("onCreate", "onResume", "onPause", "onStop", "onDestroy"):
        fn = getattr(main, name, None)
        if callable(fn):
            _core.set_lifecycle_callback(name, fn)


try:
    _auto_register_lifecycle()
except Exception:
    pass
