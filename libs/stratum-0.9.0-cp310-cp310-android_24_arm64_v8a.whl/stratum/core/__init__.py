from .stratum_object import StratumObject, _wrap_instance, _get_parent_class
